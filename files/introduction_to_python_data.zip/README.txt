This is the data for the Introduction to Programming with Python lesson.
